﻿//function changeMarks(sender) {
//    //$(".add-filter-panel").ejWaitingPopup();
//    //$(".add-filter-panel").ejWaitingPopup("show");
//    UpdateGrid(sender.selectedText);
//}
$(function () {
    $(document).ready(function () 
    {
        UpdateGrid(jClss, jExamName, jsubName);
        //var jexName = data.ExamName;
        //var jclss = data.clss;
        //var jsubName = data.SubName;
        //UpdateGrid(jclss, jsubName, jexName, );
        //alert('@ViewBag.Clss');

        alert("Ready");
        // $("#ClssGrid").ejGrid({
        //     dataSource: dataManger
        //});
        //$('#selectMarks').data("ejDropDownList").selectItemByText("All");
    });
});

function UpdateGrid(uclss,  uExamName, uSubName) {
    var dataManager = ej.DataManager({
        url: "/Marks/DataSource?clss=" + uclss + "&ExamName=" + uExamName + "&SubName=" + uSubName,
        updateUrl: "/Marks/Update",
        adaptor: new ej.UrlAdaptor()
        //offline: true,
        //requiresFormat: false,
        //crossDomain: true
    });
    $("#MarksGrid").ejGrid({
        dataSource: dataManager,
        allowPaging: true
    });

    //dataManger.ready.done(function (e) {
    //    $("#clssGrid").ejGrid({
    //        dataSource: e.dataManger
    //    });
    //});
}