﻿
//$(function () {
//    $(document).ready(function () {
//        //alert("Ready");
//        // $("#ClssGrid").ejGrid({
//        //     dataSource: dataManger
//        //});
//        //$('#selectSession').data("ejDropDownList").selectItemByText("All");
//    });
//});

//function getStudent(uniReg) {
//    //var url = '@Url.Action("Index", "FeeForms")';

//    $.ajax({
//        //url: '@Url.Action("Index", "FeeForms")',
//        url: '/FeeForms/Details',
//        type: 'GET',
//        dataType: 'json',
//        // we set cache: false because GET requests are often cached by browsers
//        // IE is particularly aggressive in that respect
//        cache: false,
//        data: { uniReg: uniReg },
//        success: function () {
//            //$('#FirstName').val(person.FirstName);
//            //$('#LastName').val(person.LastName);
//        }
//    });
//}
