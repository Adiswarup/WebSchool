﻿function changeActGrp(sender) {
    UpdateGrid(sender.selectedText);
}
function UpdateGrid(ActGrp) {
    var dataManager = ej.DataManager({
        url: "/Activities/DataSource/?ActGrp=" + ActGrp,
        updateUrl: "/Activities/Update",
        adaptor: new ej.UrlAdaptor()
    });
    $("#ActGrid").ejGrid({
        dataSource: dataManager,
        allowPaging: true
    });
}