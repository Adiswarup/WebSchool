﻿var jClss = "";
var jSession = "";
var jStdFeeCat = "";

function changeClsses(sender) {
    jClss = sender.selectedText;
    jStdFeeName = "";
    $("#DynaF").submit();
}

function changeSession(sender) {
    jSession = sender.selectedText;
    jStdFeeName = "";
    $("#DynaF").submit();
}

function changeStdFeeCat(sender) {
    jStdFeeCat = sender.value;
    jStdFeeName = "";
    $("#DynaF").submit();
}

//function UpdateGrid() {
    
//    if (jClss != "") {
//        if (jSession != "") {
//            if (jStdFeeCat != "") {
//                if (jStdFeeName != "") {
//                    //alert(jClss + "  " + jSession + "  " + jStdFeeCat)
//                    var dataManager = ej.DataManager({
//                        url: "/DynaFees/DataSource?clss=" + jClss + "&tSess=" + jSession + "&StdFeeCat=" + jStdFeeCat,
//                        updateUrl: "/DynaFees/Update?clss=" + jClss + "&tSess=" + jSession + "&StdFeeCat=" + jStdFeeCat,
//                        adaptor: new ej.UrlAdaptor()
//                    });
//                    $("#dynaGrid").ejGrid({
//                        dataSource: dataManager,
//                        allowPaging: true,
//                        updateUrl: UpdateGrid
//                    });
//                }
//            }
//        }
//    }
//}

function click(args) {
    if (this.model.editSettings.editMode === "normal") {
        this.startEdit(args.row);  //trigger to edit the row 
    }
} 