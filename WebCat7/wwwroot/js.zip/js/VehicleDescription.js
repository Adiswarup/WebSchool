﻿
$(function () {
    $(document).ready(function () {
         UpdateGrid();
    });
 });



// Updating the grid and chart contents
function UpdateGrid() {
    var dataManager = ej.DataManager({
        url: "/VehicleDescriptions/DataSource",
        updateUrl: "/VehicleDescriptions/Update",
        adaptor: new ej.UrlAdaptor()
    });
    $("#vdGrid").ejGrid({
        dataSource: dataManager,
        allowPaging: true
    });
}