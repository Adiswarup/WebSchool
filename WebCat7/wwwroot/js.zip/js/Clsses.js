﻿function changeSession(sender) {
    //$(".add-filter-panel").ejWaitingPopup();
    //$(".add-filter-panel").ejWaitingPopup("show");
    UpdateGrid(sender.selectedText);
}


$(function () {
    $(document).ready(function () {
         alert("Ready");
        // $("#ClssGrid").ejGrid({
        //     dataSource: dataManger
        //});
         //$('#selectSession').data("ejDropDownList").selectItemByText("All");
    });
 });



// Updating the grid and chart contents
function UpdateGrid(session) {
    var dataManager = ej.DataManager({
        url: "/Clsses/DataSource?sess=" + session,
        updateUrl: "/Clsses/Update",
        adaptor: new ej.UrlAdaptor()
        //offline: true,
        //requiresFormat: false,
        //crossDomain: true
    });
    $("#clssGrid").ejGrid({
        dataSource: dataManager,
        allowPaging: true
    });

    //dataManger.ready.done(function (e) {
    //    $("#clssGrid").ejGrid({
    //        dataSource: e.dataManger
    //    });
    //});
}