﻿$(function () {
    $(document).ready(function () {
        UpdateGrid();
    });
 });



// Updating the grid and chart contents
function UpdateGrid() {
    var dataManager = ej.DataManager({
        url: "/ActivityGroups/DataSource/" ,
        updateUrl: "/ActivityGroups/Update",
        adaptor: new ej.UrlAdaptor()
    });
    $("#ActGrpGrid").ejGrid({
        dataSource: dataManager,
        allowPaging: true
    });
}