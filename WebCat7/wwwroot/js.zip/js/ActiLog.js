﻿var jClss = "";
var jActGrps = "";


//$(function () {
    //$(document).show(function () {
    //    var grid = document.getElementById("Grid").ej2_instances[0];
    //    var column = grid.getColumnByField("ActName");
    //    column.headerText = "aef";
    //    var column1 = grid.getColumnByField("ActName1");
    //    column1.visible = false;
    //    // $("#ClssGrid").ejGrid({
    //    document.
    //        alert("Ready");



    //});
    $(document).ready(function () {
        jClss = $('#selectClsses').data("ejDropDownList").selectItemByIndex(0);
        jActGrps = $('#selectActGrps').data("ejDropDownList").selectItemByIndex(0);
        //var jClss = ""; // ('#selectClsses').selectedText;
        //var jActGrps = ""; // ('#selectActGrps').selectedText;

        //     dataSource: dataManger
        //});
        var grid = document.getElementById("Grid").ej2_instances[0];
        var column = grid.getColumnByField("ActName");
        column.headerText = "aef";
        var column1 = grid.getColumnByField("ActName1");
        column1.visible = false;
        // $("#ClssGrid").ejGrid({
        document.
            alert("Ready");
  });
});


function changeClsses(sender) {
    jClss = sender.selectedText;
    UpdateGrid(jClss, jActGrps);
}

function changeActGrps(sender) {
    jActGrps = sender.selectedText;
    UpdateGrid(jClss, jActGrps);
}

// Updating the grid and chart contents
function UpdateGrid(clss, actGrps) {
    var dataManager = ej.DataManager({
        url: "/ActiLogs/DataSource/?clss=" + clss + "&actGrps=" + actGrps,
        updateUrl: "/ActiLogs/Update",
        adaptor: new ej.UrlAdaptor(),

        //offline: true,
        //requiresFormat: false,
        //crossDomain: true
    });
    $("#ActiLogGrid").ejGrid({
        dataSource: dataManager,
        allowPaging: true
    });

    //$("#ActiLogGrid").ejGrid({
    //    dataBound: function (args) {
    //        var column = args.model.columns[0];
    //        column.isPrimaryKey = true;
    //        column.headerText = "Adi";
    //        this.columns(column, "update");
    //    }
    //});

    //dataManger.ready.done(function (e) {
    //    $("#clssGrid").ejGrid({
    //        dataSource: e.dataManger
    //    });
    //});
}

function dataBound(args) {
    for (var i = cCnt; i < cCnt + 5; i++) {
        var column = args.model.columns[i];
        column.isPrimaryKey = true;
        column.headerText = "i" + i;
        this.columns(column, "update");
    }

}
