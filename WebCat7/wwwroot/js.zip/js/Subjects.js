﻿function changeClsses(sender) {
    UpdateGrid(sender.itemData);
}
//$(function () {
//    $(document).ready(function () {
//        $('#selectClsses').data("ejDropDownList").selectItemByText("All");
//    });
//});

function UpdateGrid(clss) {
    var dataManager = ej.DataManager({
        url: "/Subjects/DataSource?clss=" + clss,
        updateUrl: "/Subjects/Update",
        adaptor: new ej.UrlAdaptor()
    });

    $("#subsGrid").ejGrid({
        dataSource: dataManager,
        allowPaging: true
    });
}