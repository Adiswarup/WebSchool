﻿var jClss = "";
//var jAtType = "";
//var jAtDate = Date.now;

function changeClsses(sender) {
    jClss = sender.selectedText;
    UpdateGrid(jClss );
}

//function changeType(sender) {
//    jAtType = sender.selectedText;
//    UpdateGrid(jClss, jAtType, jAtDate);
//}

//function changeDate(sender) {
//    jAtDate = sender.value;
//    UpdateGrid(jClss, jAtDate);
//}

//$(function () {
//    $(document).ready(function () {
//        $("#selectDate").ejDatePicker({ dateFormat: "dd/MM/yyyy" });
//        $("#selectDate").ejDatePicker({ maxDate: new Date("01/04/2019") });
//        $("#selectDate").ejDatePicker({ value: Date.now });
//    });
//});

function UpdateGrid(clss) {
    if  (clss !== "") {
        var stDate = document.getElementById("selectDate").value
        var dataManager = ej.DataManager({
            url: "/Conveyances/DataSource?clss=" + clss + "&stDate=" + stDate,
            updateUrl: "/Conveyances/Update/?clss=" + clss + "&stDate=" + stDate,
            adaptor: new ej.UrlAdaptor()
            //offline: true,
            //requiresFormat: false,
            //crossDomain: true
        });
    };
    $("#convGrid").ejGrid({
        dataSource: dataManager,
        allowPaging: true
    });

    //dataManger.ready.done(function (e) {
    //    $("#clssGrid").ejGrid({
    //        dataSource: e.dataManger
    //    });
    //});
}

//function click(args) {
//    if (this.model.editSettings.editMode == "normal") {
//        this.startEdit(args.row);  //trigger to edit the row 
//    }
//} 