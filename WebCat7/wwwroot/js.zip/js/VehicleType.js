﻿$(function () {
    $(document).ready(function () {
        UpdateGrid();
    });
});

// Updating the grid and chart contents
function UpdateGrid() {
    var dataManager = ej.DataManager({
        url: "/VehicleTypes/DataSource",
        updateUrl: "/VehicleTypes/Update",
        adaptor: new ej.UrlAdaptor()
    });
    $("#vtGrid").ejGrid({
        dataSource: dataManager,
        allowPaging: true
    });
}