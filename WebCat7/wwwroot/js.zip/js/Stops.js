﻿
$(function () {
    $(document).ready(function () {
         UpdateGrid();
    });
 });



// Updating the grid and chart contents
function UpdateGrid() {
    var dataManager = ej.DataManager({
        url: "/stops/DataSource",
        updateUrl: "/stops/Update",
        adaptor: new ej.UrlAdaptor()
    });
    $("#stopsGrid").ejGrid({
        dataSource: dataManager,
        allowPaging: true
    });
}

function click(args) {
    if (this.model.editSettings.editMode == "normal") {
        this.startEdit(args.row);  //trigger to edit the row 
    }
} 